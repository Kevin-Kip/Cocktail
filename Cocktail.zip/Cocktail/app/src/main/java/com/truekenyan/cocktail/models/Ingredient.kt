package com.truekenyan.cocktail.models

data class Ingredient(val name: String?, val measure: String?)