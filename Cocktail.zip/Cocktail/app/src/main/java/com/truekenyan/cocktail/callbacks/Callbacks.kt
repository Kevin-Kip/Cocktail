package com.truekenyan.cocktail.callbacks

interface Callbacks {
    fun onTitleFound(name: String?)
    fun onRemoveClicked(name: String?)
}